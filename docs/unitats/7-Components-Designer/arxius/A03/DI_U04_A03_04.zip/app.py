from idiomas.africa import suahili
print(suahili.saludo)

import idiomas.europa
print(idiomas.europa.español.saludo)

import idiomas.europa.ingles as ingles
print(ingles.saludo) 